import { useParams, useLocation, Link, useNavigate } from "react-router-dom";
import { EVENTS } from "./Index";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  ChevronLeft,
  CreditCard,
  Lock,
  ShieldCheck,
  Calendar,
  MapPin,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";

const Checkout = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const ticketTypeIndex = parseInt(queryParams.get("type") || "0");

  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Resolve event defensively
  const event = EVENTS.find(e => String(e.id) === id) || EVENTS[0];

  const ticketTypes = [
    { name: "General Admission", price: 45 },
    { name: "Premium Grandstand", price: 85 },
    { name: "VIP Diamond Lounge", price: 250 }
  ];

  const selectedTicket = ticketTypes[ticketTypeIndex];
  const fee = 4.50;
  const total = selectedTicket.price + fee;

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      toast({
        title: "Booking Confirmed!",
        description: "Your tickets have been sent to your email.",
      });
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card className="max-w-md w-full border-none shadow-2xl rounded-3xl overflow-hidden animate-in fade-in zoom-in duration-500">
          <div className="bg-secondary p-8 text-center">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <CheckCircle2 className="w-12 h-12 text-secondary" />
            </div>
            <h1 className="text-3xl font-heading font-extrabold text-white">Winning!</h1>
            <p className="text-white/80 font-body mt-2">Your booking is secured.</p>
          </div>
          <CardContent className="p-8 space-y-6 bg-white">
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">Order Number</span>
                <span className="font-bold text-primary">#EQ-8829410</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">Event</span>
                <span className="font-bold text-primary truncate ml-4 text-right">{event.title}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">Tickets</span>
                <span className="font-bold text-primary">1x {selectedTicket.name}</span>
              </div>
            </div>

            <div className="bg-background p-4 rounded-xl flex items-start gap-3 border border-primary/10">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                A confirmation email has been sent to your address. Please bring your digital ticket or a printed copy to the venue entry.
              </p>
            </div>

            <Button
              className="w-full h-14 bg-primary text-white font-bold rounded-xl hover:bg-primary/90"
              onClick={() => navigate("/")}
            >
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-6 py-12">
        <Link to={`/event/${id}`} className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ChevronLeft className="w-5 h-5" />
          <span className="font-medium">Back to event selection</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">

          {/* Checkout Form */}
          <div className="lg:col-span-2 space-y-8">
            <section className="space-y-6">
              <h2 className="text-3xl font-heading font-extrabold text-primary">Secure Checkout</h2>

              <Card className="border-none shadow-lg rounded-2xl bg-white">
                <CardContent className="p-8 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" placeholder="John" className="h-12 border-[#e5c12e]" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" placeholder="Doe" className="h-12 border-[#e5c12e]" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" placeholder="john@example.com" className="h-12 border-[#e5c12e]" />
                  </div>
                </CardContent>
              </Card>

              <div className="flex items-center justify-between pt-4">
                <h3 className="text-xl font-heading font-bold text-primary flex items-center gap-2">
                  <CreditCard className="w-6 h-6 text-secondary" />
                  Payment Information
                </h3>
              </div>

              <Card className="border-none shadow-lg rounded-2xl overflow-hidden bg-white">
                <div className="bg-secondary/10 p-4 border-b border-secondary/20 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-secondary" />
                  <span className="text-xs font-bold text-secondary uppercase tracking-wider">Encrypted SSL Payment</span>
                </div>
                <CardContent className="p-8 space-y-6">
                  <form onSubmit={handlePayment} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="cardName">Name on Card</Label>
                      <Input id="cardName" placeholder="JOHN DOE" className="h-12 uppercase border-[#e5c12e]" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <div className="relative">
                        <Input id="cardNumber" placeholder="0000 0000 0000 0000" className="h-12 pr-10 border-[#e5c12e]" />
                        <CreditCard className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input id="expiry" placeholder="MM/YY" className="h-12 border-[#e5c12e]" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cvc">CVC</Label>
                        <Input id="cvc" placeholder="123" className="h-12 border-[#e5c12e]" />
                      </div>
                    </div>

                    <div className="pt-4">
                      <Button
                        disabled={isProcessing}
                        className="w-full h-16 bg-primary text-white font-heading font-bold text-lg rounded-xl hover:bg-primary/90 shadow-xl transition-all active:scale-[0.98]"
                      >
                        {isProcessing ? "Processing Securely..." : `Pay £${total.toFixed(2)} Now`}
                      </Button>
                      <p className="text-center text-xs text-muted-foreground mt-4 flex items-center justify-center gap-1">
                        <ShieldCheck className="w-3 h-3" />
                        Verified by Equestrian Trust &bull; Official Ticket Reseller
                      </p>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </section>
          </div>

          {/* Booking Summary Sidebar */}
          <div className="space-y-6">
            <h3 className="text-xl font-heading font-bold text-primary">Booking Summary</h3>
            <Card className="border-none shadow-xl rounded-3xl overflow-hidden bg-white">
              <div className="relative h-32">
                <img src={event.img_url} className="w-full h-full object-cover" alt={event.title} />
                <div className="absolute inset-0 bg-secondary/40 backdrop-blur-[2px]" />
                <div className="absolute inset-0 flex items-center justify-center p-4">
                  <h4 className="text-white font-heading font-bold text-center leading-tight">
                    {event.title}
                  </h4>
                </div>
              </div>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm font-body text-slate-600">
                    <Calendar className="w-4 h-4 text-secondary" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm font-body text-slate-600">
                    <MapPin className="w-4 h-4 text-secondary" />
                    <span>{event.location}</span>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4 font-body">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">1x {selectedTicket.name}</span>
                    <span className="font-semibold text-primary">£{selectedTicket.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Booking Fee</span>
                    <span className="font-semibold text-primary">£{fee.toFixed(2)}</span>
                  </div>
                </div>

                <Separator className="bg-primary/10" />

                <div className="flex justify-between items-center pt-2">
                  <span className="font-heading font-bold text-primary uppercase tracking-wider text-sm">Total Amount</span>
                  <span className="text-3xl font-heading font-extrabold text-primary">£{total.toFixed(2)}</span>
                </div>

                <div className="bg-[#ffe357] p-4 rounded-2xl space-y-2 border border-primary/10">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span className="text-xs font-bold text-slate-700">Instant Confirmation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span className="text-xs font-bold text-slate-700">Digital Tickets Sent Via Email</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Checkout;