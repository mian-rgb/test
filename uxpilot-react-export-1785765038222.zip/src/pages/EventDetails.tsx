import { useParams, Link, useNavigate } from "react-router-dom";
import { EVENTS } from "./Index";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calendar,
  MapPin,
  Clock,
  Info,
  ChevronLeft,
  Ticket,
  ShieldCheck,
  Star,
  Users,
  Trophy
} from "lucide-react";

const EventDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Resolve event defensively
  const event = EVENTS.find(e => String(e.id) === id) || EVENTS[0];

  const ticketTypes = [
    {
      name: "General Admission",
      price: 45,
      description: "Standard arena access, unreserved seating in the South stand.",
      benefits: ["Arena Access", "Exhibitor Village", "Digital Programme"]
    },
    {
      name: "Premium Grandstand",
      price: 85,
      description: "Reserved seating with prime views of the arena and jump sequences.",
      benefits: ["Reserved Seating", "Cushioned Seats", "Fast-track Entry"]
    },
    {
      name: "VIP Diamond Lounge",
      price: 250,
      description: "The ultimate luxury experience with gourmet hospitality.",
      benefits: ["Premium Hospitality", "Private Bar", "Rider Meet & Greet"]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Detail Header */}
      <div className="bg-primary text-white pb-20 pt-10">
        <div className="container mx-auto px-6">
          <Link to="/" className="inline-flex items-center gap-2 text-white/70 hover:text-secondary mb-8 transition-colors">
            <ChevronLeft className="w-5 h-5" />
            <span className="font-medium">Back to events</span>
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-end">
            <div>
              <Badge className="bg-secondary text-primary font-bold mb-4">
                {event.type}
              </Badge>
              <h1 className="text-4xl md:text-5xl font-heading font-extrabold mb-6">
                {event.title}
              </h1>
              <div className="flex flex-wrap gap-6 text-white/80 font-body">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-secondary" />
                  <span>{event.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-secondary" />
                  <span>{event.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-secondary" />
                  <span>Doors open: 08:30 AM</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 lg:justify-end">
              <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10 h-14 px-8">
                Add to Calendar
              </Button>
              <Button
                size="lg"
                className="bg-secondary text-primary font-bold h-14 px-8 hover:bg-accent gold-glow shadow-lg"
                onClick={() => navigate(`/checkout/${event.id}`)}
              >
                Book Tickets Now
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 -mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Left Column: Info & Tabs */}
          <div className="lg:col-span-2 space-y-8">
            <div className="rounded-3xl overflow-hidden shadow-2xl bg-white border border-border/50">
              <img src={event.img_url} className="w-full h-[400px] object-cover" alt={event.title} />

              <div className="p-8">
                <Tabs defaultValue="about" className="w-full">
                  <TabsList className="bg-muted p-1 mb-8 w-full justify-start overflow-x-auto no-scrollbar">
                    <TabsTrigger value="about" className="data-[state=active]:bg-white px-8">About</TabsTrigger>
                    <TabsTrigger value="schedule" className="data-[state=active]:bg-white px-8">Schedule</TabsTrigger>
                    <TabsTrigger value="venue" className="data-[state=active]:bg-white px-8">Venue Info</TabsTrigger>
                    <TabsTrigger value="riders" className="data-[state=active]:bg-white px-8">Top Riders</TabsTrigger>
                  </TabsList>

                  <TabsContent value="about" className="space-y-6">
                    <h3 className="text-2xl font-heading font-bold text-primary">Experience the Magic</h3>
                    <p className="text-muted-foreground leading-relaxed font-body">
                      Join us for an unforgettable showcase of equestrian skill and athletic prowess. The {event.title} brings together the world's elite riders and horses for a competition that combines technical precision with sheer power.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4">
                      <div className="flex flex-col items-center p-6 bg-muted rounded-2xl text-center">
                        <Users className="w-8 h-8 text-primary mb-3" />
                        <span className="text-xl font-bold text-primary">15,000+</span>
                        <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Attendance</span>
                      </div>
                      <div className="flex flex-col items-center p-6 bg-muted rounded-2xl text-center">
                        <Trophy className="w-8 h-8 text-primary mb-3" />
                        <span className="text-xl font-bold text-primary">£500k</span>
                        <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Prize Fund</span>
                      </div>
                      <div className="flex flex-col items-center p-6 bg-muted rounded-2xl text-center">
                        <Star className="w-8 h-8 text-primary mb-3" />
                        <span className="text-xl font-bold text-primary">Elite</span>
                        <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Classification</span>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="schedule" className="space-y-4">
                    {[
                      { time: "09:00", event: "Morning Warm-ups & Training" },
                      { time: "10:30", event: "Classification Rounds - Group A" },
                      { time: "13:00", event: "Midday Interval & Exhibitions" },
                      { time: "14:30", event: "Semi-Finals Tournament" },
                      { time: "16:30", event: "Grand Finale & Podium Presentation" }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between p-4 rounded-xl hover:bg-muted transition-colors border border-border/20">
                        <span className="font-bold text-primary w-20">{item.time}</span>
                        <span className="flex-1 font-body text-slate-700">{item.event}</span>
                        <div className="w-2 h-2 rounded-full bg-secondary" />
                      </div>
                    ))}
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>

          {/* Right Column: Ticket Picker */}
          <div className="space-y-6">
            <Card className="border-none shadow-xl rounded-3xl sticky top-24 overflow-hidden">
              <div className="bg-primary p-6 text-white text-center">
                <h3 className="text-xl font-heading font-bold">Select Tickets</h3>
                <p className="text-white/60 text-sm font-body">Official Platinum Partner</p>
              </div>
              <CardContent className="p-6 space-y-4">
                {ticketTypes.map((ticket, i) => (
                  <div
                    key={i}
                    className="group p-5 rounded-2xl border-2 border-border hover:border-secondary hover:bg-secondary/5 transition-all cursor-pointer"
                    onClick={() => navigate(`/checkout/${event.id}?type=${i}`)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-primary group-hover:text-primary">{ticket.name}</h4>
                      <span className="text-xl font-bold text-primary">£{ticket.price}</span>
                    </div>
                    <p className="text-sm text-muted-foreground font-body mb-3 leading-snug">
                      {ticket.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {ticket.benefits.slice(0, 2).map((benefit, j) => (
                        <div key={j} className="flex items-center gap-1 text-[10px] uppercase tracking-widest font-bold text-secondary-foreground/60">
                          <ShieldCheck className="w-3 h-3" />
                          {benefit}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                <div className="pt-4 space-y-4">
                  <div className="p-4 bg-muted/50 rounded-xl flex items-center gap-3">
                    <Info className="w-5 h-5 text-primary" />
                    <p className="text-xs text-muted-foreground font-body">
                      Children under 5 enter free. All prices inclusive of VAT and booking fees.
                    </p>
                  </div>
                  <Button
                    className="w-full bg-secondary text-primary font-bold h-14 rounded-xl hover:bg-accent text-lg"
                    onClick={() => navigate(`/checkout/${event.id}`)}
                  >
                    Proceed to Booking
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="p-6 bg-primary/5 rounded-3xl border border-primary/10 flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-md">
                <Ticket className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h5 className="font-bold text-primary text-sm">Need help?</h5>
                <p className="text-xs text-muted-foreground">Contact our VIP concierge team</p>
              </div>
            </div>
          </div>

        </div>
      </div>

      <footer className="mt-20 py-10 text-center text-muted-foreground text-sm font-body border-t border-border">
        &copy; 2024 EquiTickets &bull; Secure Ticket Distribution
      </footer>
    </div>
  );
};

export default EventDetails;