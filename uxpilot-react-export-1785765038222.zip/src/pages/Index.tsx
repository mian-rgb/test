import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Trophy, Search, ChevronRight } from "lucide-react";

export const EVENTS = [
  {
    id: 1,
    title: "Grand Prix Show Jumping Championships",
    date: "Sept 15-18, 2024",
    location: "Greenwich Arena, London",
    type: "Show Jumping",
    price: "From £45",
    img_url: "https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_88b90901d6_22b0d072417a31fb.png",
    featured: true
  },
  {
    id: 2,
    title: "National Dressage Masters",
    date: "Oct 02, 2024",
    location: "Royal Windsor Great Park",
    type: "Dressage",
    price: "From £35",
    img_url: "https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_21dbb4cbd9_f1ec4d67f7b5f883.png"},
  {
    id: 3,
    title: "The Autumn Eventing Trials",
    date: "Oct 12-14, 2024",
    location: "Blenheim Palace grounds",
    type: "Eventing",
    price: "From £25",
    img_url: "https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_e5305fdf5f_148f795d484e8fa4.png"},
  {
    id: 4,
    title: "Indoor Polo World Series",
    date: "Nov 05, 2024",
    location: "The O2 Arena, London",
    type: "Polo",
    price: "From £60",
    img_url: "https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_246a9a7d7b_0332013ed1ed90a5.png"},
  {
    id: 5,
    title: "Winter Hunter Classics",
    date: "Dec 10, 2024",
    location: "Midlands Equestrian Centre",
    type: "Hunter/Jumper",
    price: "From £30",
    img_url: "https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_28dd531f47_bae84988c8829557.png"},
  {
    id: 6,
    title: "Pony Club National Finals",
    date: "Jan 22, 2025",
    location: "National Agricultural Centre",
    type: "Mixed Disciplines",
    price: "From £15",
    img_url: "https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_264aa9a5d0_395421d76f4c94ca.png"}
];

const Navbar = () => (
  <nav className="flex items-center justify-between px-6 py-4 bg-primary text-white sticky top-0 z-50 shadow-md">
    <Link to="/" className="flex items-center gap-2">
      <div className="w-8 h-8 bg-secondary rounded-lg flex items-center justify-center">
        <Trophy className="w-5 h-5 text-primary" />
      </div>
      <span className="font-heading font-extrabold text-xl tracking-tight text-secondary">EQUITICKETS</span>
    </Link>
    <div className="hidden md:flex items-center gap-8 font-body font-medium text-sm">
      <Link to="/" className="hover:text-secondary transition-colors">Find Shows</Link>
      <Link to="#" className="hover:text-secondary transition-colors">Venues</Link>
      <Link to="#" className="hover:text-secondary transition-colors">Support</Link>
    </div>
    <div className="flex items-center gap-4">
      <Button variant="ghost" className="text-white hover:text-secondary">My Bookings</Button>
      <Button className="bg-secondary text-primary font-bold hover:bg-accent transition-all">Sign In</Button>
    </div>
  </nav>
);

const Index = () => {
  const featuredEvent = EVENTS[0];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img className="w-full h-full object-cover" src="https://storage.googleapis.com/uxpilot-dev.appspot.com/gen_763688b887_9410480d5c0e1a0f.png" alt="cinematic shot of a championship horse show arena at night with grandstand lights, prestigious atmos" />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/60 to-transparent" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-2xl">
            <Badge className="bg-secondary text-primary font-bold mb-4 px-3 py-1">
              SEASON TICKETS NOW ON SALE
            </Badge>
            <h1 className="text-5xl md:text-7xl font-heading font-extrabold text-white mb-6 leading-tight">
              Witness the <span className="text-secondary italic">Excellence</span> of Equestrian Sport
            </h1>
            <p className="text-lg text-white/80 font-body mb-8 leading-relaxed">
              Book your place at the world's most prestigious horse shows. From high-stakes show jumping to the grace of grand prix dressage.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-secondary text-primary font-bold px-8 h-14 text-lg hover:bg-accent gold-glow">
                Explore Events
              </Button>
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search by show, rider or venue..."
                  className="w-full h-14 pl-10 pr-4 rounded-xl border-none ring-1 ring-white/20 bg-white/10 backdrop-blur-md text-white placeholder:text-white/40 focus:ring-2 focus:ring-secondary outline-none transition-all"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories / Filter Pills */}
      <div className="container mx-auto px-6 -translate-y-1/2 relative z-20">
        <div className="bg-white rounded-2xl shadow-xl p-4 flex gap-4 overflow-x-auto no-scrollbar border border-border/50">
          {["All Disciplines", "Show Jumping", "Dressage", "Eventing", "Polo", "Showing"].map((cat, i) => (
            <Button
              key={cat}
              variant={i === 0 ? "default" : "outline"}
              className={i === 0 ? "bg-primary text-white" : "text-primary border-primary/20 hover:bg-primary/5"}
            >
              {cat}
            </Button>
          ))}
        </div>
      </div>

      {/* Event Grid */}
      <section className="container mx-auto px-6 py-12 bg-background">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-heading font-bold text-primary">Upcoming Championships</h2>
            <p className="text-muted-foreground font-body">Don't miss the biggest events of the 2024 season</p>
          </div>
          <Button variant="ghost" className="text-primary font-semibold flex items-center gap-2">
            View All Events <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {EVENTS.map((event) => (
            <Link key={event.id} to={`/event/${event.id}`}>
              <Card className="group overflow-hidden border-none shadow-lg hover:shadow-2xl transition-all duration-300 rounded-2xl bg-white h-full flex flex-col">
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={event.img_url}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    alt={event.title}
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-primary/80 backdrop-blur-md text-white border-none">
                      {event.type}
                    </Badge>
                  </div>
                  <div className="absolute bottom-4 right-4">
                    <div className="bg-secondary text-primary font-bold px-3 py-1 rounded-lg text-sm shadow-md">
                      {event.price}
                    </div>
                  </div>
                </div>
                <CardContent className="p-6 flex-1">
                  <h3 className="text-xl font-heading font-bold text-primary mb-3 group-hover:text-secondary transition-colors">
                    {event.title}
                  </h3>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-muted-foreground text-sm font-body">
                      <Calendar className="w-4 h-4 text-secondary" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground text-sm font-body">
                      <MapPin className="w-4 h-4 text-secondary" />
                      <span>{event.location}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="px-6 pb-6 pt-0">
                  <Button className="w-full bg-muted text-primary hover:bg-secondary hover:text-primary transition-all font-bold">
                    Book Tickets
                  </Button>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="bg-primary py-20 mt-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
          <Trophy className="w-full h-full text-white rotate-12" />
        </div>
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-extrabold text-white mb-4">
            Never Miss a Winning Moment
          </h2>
          <p className="text-white/70 font-body mb-8 max-w-xl mx-auto">
            Subscribe to our newsletter for exclusive early access to championship tickets and seasonal discounts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 h-12 px-6 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:ring-2 focus:ring-secondary outline-none"
            />
            <Button className="bg-secondary text-primary font-bold h-12 px-8 hover:bg-accent">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      <footer className="bg-primary/10 py-12 border-t border-primary/5">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-secondary rounded-md flex items-center justify-center">
                <Trophy className="w-4 h-4 text-white" />
              </div>
              <span className="font-heading font-extrabold text-lg tracking-tight text-primary">EQUITICKETS</span>
            </div>
            <div className="flex gap-8 text-sm text-muted-foreground font-body">
              <Link to="#" className="hover:text-primary transition-colors">Privacy Policy</Link>
              <Link to="#" className="hover:text-white transition-colors">Terms of Service</Link>
              <Link to="#" className="hover:text-white transition-colors">Contact Us</Link>
            </div>
            <div className="text-muted-foreground/60 text-xs font-body">
              &copy; 2024 EquiTickets. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;